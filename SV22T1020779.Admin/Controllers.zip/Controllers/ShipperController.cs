﻿using Microsoft.AspNetCore.Mvc;

namespace SV22T1020779.Admin.Controllers
{
    public class ShipperController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult Create()
        {
            ViewBag.Title = "Bổ sung Người giao hàng";
            return View("Edit");
        }
        public IActionResult Edit(int id)
        {
            ViewBag.Title = "Cập nhật thông tin người giao hàng";
            return View("Edit");
        }
        public IActionResult Delete(int id)
        {
            return View();
        }
    }
}
