﻿using Microsoft.AspNetCore.Mvc;

namespace SV22T1020779.Admin.Controllers
{
    public class EmployeeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult Create()
        {
            ViewBag.Title = "Bổ sung nhân viên";
            return View("Edit");
        }
        public IActionResult Edit(int id)
        {
            ViewBag.Title = "Cập nhật thông nhân viên";
            return View("Edit");
        }
        public IActionResult ChangePassword(int id)
        {
            ViewBag.Title = "Đổi mật khẩu";
            return View("ChangePassword");
        }
        public IActionResult ChangeRoles(int id)
        {
            ViewBag.Title = "Phân quyền";
            return View("ChangeRole");
        }
        public IActionResult Delete(int id)
        {
            return View();
        }
    }
}
