﻿using Microsoft.AspNetCore.Mvc;
using SV22T1020779.BusinessLayers;
using SV22T1020779.Models;

namespace SV22T1020779.Admin.Controllers
{
    public class SupplierController : Controller
    {
       public IActionResult Index()
        {
            return View();
        }
        public IActionResult Create()
        {
            ViewBag.Title = "Bổ sung Nhà cung cấp";
            return View("Edit");
        }
        public IActionResult Edit(int id)
        {
            ViewBag.Title = "Cập nhật thông tin nhà cung cấp";
            return View("Edit");
        }
        public IActionResult Delete(int id)
        {
            return View();
        }
    }
}
