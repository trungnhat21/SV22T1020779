﻿using Microsoft.AspNetCore.Mvc;

namespace SV22T1020779.Admin.Controllers
{
    public class AccountController : Controller
    {
        public IActionResult Login()
        {
            return View();
        }
        public IActionResult ChangePassword()
        {
            return View();
        }
    }
}
