﻿using Microsoft.AspNetCore.Mvc;

namespace SV22T1020779.Admin.Controllers
{
    public class ProductController : Controller
    {
        // =========================
        // Danh sách sản phẩm
        // =========================
        public IActionResult Index()
        {
            return View();
        }

        // =========================
        // Thêm mới
        // =========================
        public IActionResult Create()
        {
            ViewBag.Title = "Bổ sung mặt hàng";
            return View("Edit");
        }

        // =========================
        // Cập nhật
        // =========================
        public IActionResult Edit(int id)
        {
            ViewBag.Title = "Cập nhật thông tin mặt hàng";
            return View("Edit");
        }

        // =========================
        // Chi tiết
        // =========================
        public IActionResult Detail(int id)
        {
            ViewBag.Title = "Chi tiết mặt hàng";
            return View("Detail");
        }

        // =========================
        // Xóa
        // =========================
        public IActionResult Delete(int id)
        {
            return View();
        }

        // ==================================================
        // HIỂN THỊ DANH SÁCH THUỘC TÍNH SẢN PHẨM
        // ==================================================

        public IActionResult ListAttributes(int id)
        {
            ViewBag.ProductId = id;
            return View();
        }

        public IActionResult CreateAttribute(int id)
        {
            ViewBag.Title = "Bổ sung thuộc tính";
            ViewBag.ProductId = id;
            return View("EditAttribute");
        }

        public IActionResult EditAttribute(int id, int attributeId)
        {
            ViewBag.Title = "Cập nhật thuộc tính";
            ViewBag.ProductId = id;
            ViewBag.AttributeId = attributeId;
            return View();
        }

        public IActionResult DeleteAttribute(int id, int attributeId)
        {
            return RedirectToAction("Edit", new { id });
        }

        // ==================================================
        // HÌNH ẢNH SẢN PHẨM
        // ==================================================

        public IActionResult ListPhotos(int id)
        {
            ViewBag.ProductId = id;
            return View();
        }

        public IActionResult CreatePhoto(int id)
        {
            ViewBag.Title = "Bổ sung ảnh sản phẩm";
            ViewBag.ProductId = id;
            return View("EditPhoto");
        }

        public IActionResult EditPhoto(int id, int photoId)
        {
            ViewBag.Title = "Cập nhật ảnh sản phẩm";
            ViewBag.ProductId = id;
            ViewBag.PhotoId = photoId;
            return View("EditPhoto");
        }

        public IActionResult DeletePhoto(int id, int photoId)
        {
            return RedirectToAction("Edit", new { id });
        }
    }
}