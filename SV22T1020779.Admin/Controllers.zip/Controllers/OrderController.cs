﻿using Microsoft.AspNetCore.Mvc;

namespace SV22T1020779.Admin.Controllers
{
    public class OrderController : Controller
    {
        // =============================
        // 1. Danh sách đơn hàng
        // =============================
        // Giao diện nhập đầu vào 
        public IActionResult Index()
        {
            return View();
        }

        // Tìm kiếm / hiển thị danh sách đơn hàng
        [HttpGet]
        public IActionResult Search(string keyword, string status)
        {
            return View("Search");
        }

        // =============================
        // 2. Lập đơn hàng
        // =============================

        // Mở trang tạo đơn
        public IActionResult Create()
        {
            return View();
        }

        // Xác nhận tạo đơn (Submit)
        [HttpPost]
        public IActionResult Create(object model)
        {
            return RedirectToAction("Index");
        }

        // =============================
        // 3. Chi tiết đơn hàng
        // =============================
        public IActionResult Detail(int id)
        {
            return View();
        }

        // =============================
        // 4. Quản lý giỏ hàng (trong Create)
        // =============================

        public IActionResult AddToCart(int id, int productId)
        {
            return RedirectToAction("Create", new { id });
        }
        // Cập nhật thông tin của 1 mặt hàng trong giỏ hàng hoặc trong chi tiết của đơn hàng
        public IActionResult EditCartItem(int id = 0, int productId = 0)
        {
            return RedirectToAction("Create", new { id });
        }

        public IActionResult DeleteCartItem(int id = 0, int productId = 0)
        {
            return RedirectToAction("Create", new { id });
        }
        // Xóa tất cả hàng trong giỏ
        public IActionResult ClearCart(int id)
        {
            return RedirectToAction("Create", new { id });
        }

        // =============================
        // 5. Quản lý trạng thái đơn
        // =============================
        // Duyệt nhận đơn hàng
        public IActionResult Accept(int id)
        {
            return RedirectToAction("Detail", new { id });
        }

        public IActionResult Shipping(int id)
        {
            return RedirectToAction("Detail", new { id });
        }
        // Ghi nhận kết thúc thành công đơn hàng
        public IActionResult Finish(int id)
        {
            return RedirectToAction("Detail", new { id });
        }
        // Từ chối đơn hàng
        public IActionResult Reject(int id)
        {
            return RedirectToAction("Detail", new { id });
        }
        // Hủy đơn hàng
        public IActionResult Cancel(int id)
        {
            return RedirectToAction("Detail", new { id });
        }

        public IActionResult Delete(int id)
        {
            return RedirectToAction("Index");
        }
    }
}