﻿using Microsoft.AspNetCore.Mvc;

namespace SV22T1020779.Admin.Controllers
{
    public class CustomerController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult Create()
        {
            ViewBag.Title = "Bổ sung Khách hàng";
            return View("Edit");
        }
        public IActionResult Edit(int id)
        {
            ViewBag.Title = "Cập nhật thông tin khách hàng";
            return View("Edit");
        }
        public IActionResult ChangePassword(int id)
        {
            ViewBag.Title = "Đổi mật khẩu";
            return View("ChangePassword");
        }
        public IActionResult Delete(int id)
        {
            return View();
        }
    }
}
